# OurSQL

![image](https://user-images.githubusercontent.com/22043590/69807530-79352180-1220-11ea-97ca-1bc58f9734a1.png)

## How to use

1. Clone this repository
`git clone https://github.com/aqhmal/mysql_bruteforce.git`

2. Install mysqlclient library using pip
`pip3 install mysqlclient`

3. Run the script
`python3 mysql.py --host <domain or ip> --pass <file containing passwords>`

You can check other options by using `-h` parameter.
Note: This tool is for educational purpose only. If you use this tool for any illegal activity, I will not be responsible for any damage or loss.
